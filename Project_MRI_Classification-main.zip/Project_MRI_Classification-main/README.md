# Project_MRI_Classification

This project is aimed at classifying magnetic resonance imaging (MRI) scans into different medical conditions like meningioma, glicoma, pituitary type of brain tumors.
I have used the dataset aquired from kaggle and augumented it to increase the number of data for each class.

Dependencies:
  * Python 3.x
  * TensorFlow 2.x
  * Numpy
  * OpenCV

I have used Tensorflow, Keras to build CNN model to classify the given image as the respective type of tumor.
Using that model I have created a website to check whether a person is signing or not.
For this I have used flask framework.
